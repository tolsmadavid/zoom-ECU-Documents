/******************** (C) COPYRIGHT 2019 STMicroelectronics **************************************
* File Name          : readme.txt
* Author             : STMicroelectronics
* Description        : This file describes how to add STM32G4xx devices support on MDK-ARM 
**************************************************************************************************

Running the "Keil.STM32G4xx_DFP.1.1.2.pack" adds the following:
  
1. Part numbers for  :
- Product lines: STM32G431xx/G471xx/G441xx/G473xx/G474xx/G484xx/G483xx
- New line to E-bike market: STM32GBK1xx

2. Automatic STM32G4 flash algorithm selection 
Note : for the STM32G4xx devices with 512kB there two Flash Loaders:
   -STM32G4xx_512_SingleBank.FLM  for the Single Bank devices
   -STM32G4xx_512_Dual.FLM        for the Dual Bank devices
Please check the bit Flash_OPTR_DBANK for the Single/Dual Bank configuration.
You can use the STM32CubeProgrammer tool. You click on OB>>User Configuration>>DBANK 

 
3. SVD file 


How to use:
==========
* Before installing the files mentioned above, you need to have MDK-ARM v5.25 
or later installed. 
You can download pack from keil web site @ www.keil.com
 
* Double Clic on  "Keil.STM32G4xx_DFP.1.1.2.pack" in order to install this pack in 
the Keil install directory.

******************* (C) COPYRIGHT 2019 STMicroelectronics *****END OF FILE************************





	



